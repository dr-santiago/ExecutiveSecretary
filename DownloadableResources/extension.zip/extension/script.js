let URL_JSESSIONID = "https://imos.churchofjesuschrist.org/ws/auth-controller";
let URL_REFERRAL = "https://referralmanager.churchofjesuschrist.org/";
let NAME_IMOS = 'JSESSIONID';
let NAME_REFERRAL = 'oauth-abw_access_token';
let USER_REFERRAl = 'oauth-abw_church_account_id';
var domain = ''

function getCookie(myUrl, name) {
    chrome.cookies.get({ url: myUrl, name: name }, function (cookie) {
        if (cookie != null) {
            if (name == NAME_IMOS) {
                activarVistas("block", "none", "none", "block");
                setData('tituloM', 'copyButtonM', 'JSessionID:', cookie.value);
            }
            else if (name == NAME_REFERRAL) {
                activarVistas("block", "none", "block", "none");
                setData('tituloR1', 'copyButtonR1', 'Access Token', cookie.value);
            }
            else if (name == USER_REFERRAl) {
                activarVistas("block", "none", "block", "none");
                setData('tituloR2', 'usuario', 'Usuario: ', cookie.value);
                document.getElementById('usuario').innerHTML = cookie.value;
            }
        }
        else {
            activarVistas("none", "block");
        }

    });
}

function activarVistas(bien, error, referencias, imos) {
    document.getElementById('bien').style.display = bien;
    document.getElementById('error').style.display = error;
    document.getElementById('referencias').style.display = referencias;
    document.getElementById('imos').style.display = imos;
}

function copyTextToClipboard(text) {
    var copyFrom = document.createElement("textarea");
    copyFrom.textContent = text;
    document.body.appendChild(copyFrom);
    copyFrom.select();
    document.execCommand('copy');
    copyFrom.blur();
    document.body.removeChild(copyFrom);
}

function setData(idTitulo, idButton, titulo, value) {
    document.getElementById(idTitulo).innerHTML = titulo;
    document.getElementById(idButton).addEventListener("click", copyTextToClipboard(value));
}

function main(domain) {
    if (domain == 'https://referralmanager.churchofjesuschrist.org/dashboard/(right-sidebar:tasks)') {
        getCookie(URL_REFERRAL, USER_REFERRAl);
        getCookie(URL_REFERRAL, NAME_REFERRAL);
    }
    else {
        getCookie(URL_JSESSIONID, NAME_IMOS);
    }
}

document.addEventListener("DOMContentLoaded", function () {
    chrome.tabs.query({
        "active": true,
        "currentWindow": true,
        "status": "complete",
        "windowType": "normal"
    }, function (tabs) {
        for (tab in tabs) {
            main(tabs[tab].url);
        }
    });
});

